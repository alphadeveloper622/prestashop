<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{relatedfree}prestashop>relatedfree_17c82299e6df09fdb6d988f6bcbd69e3'] = 'Podobne produkty (darmowy)';
$_MODULE['<{relatedfree}prestashop>relatedfree_6eb29cbec7ae39124375af6321fe620b'] = 'Darmowy moduł do wyświetlania podobnych produktów na stronach wybranych produktów';
$_MODULE['<{relatedfree}prestashop>productfooter_38070661d5ad384d9c7d21895dc4e784'] = 'Powiązane produkty';
$_MODULE['<{relatedfree}prestashop>productfooter_53d18c6edf8a8c3ad9e12960d7f34608'] = 'Brak powiązanych produktów';
