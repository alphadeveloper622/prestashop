<?php

global $_MODULE; 
$_MODULE = array(); 
$_MODULE['<{relatedfree}prestashop>relatedfree_17c82299e6df09fdb6d988f6bcbd69e3'] = 'Prodotti correlati 
(gratis)'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_6eb29cbec7ae39124375af6321fe620b'] = 'Modulo gratuito per visualizzare i prodotti analoghi sulle pagine di prodotti 
selezionati'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_ec211f7c20af43e742bf2570c3cb84f9'] = 
'Aggiungere'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_b9af8635591dc44009ccd8e5389722ec'] = 'Nessun prodotto 
trovato'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_248336101b461380a4b2391a7625493d'] = 
'Salva'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_9a51a007b33a46e553def6423aad8648'] = 'Impostazioni 
globali'; 
$_MODULE['<{relatedfree}prestashop>relatedfree_c9ae5a4214e87ad6fbed44a267471eee'] = 'Salva le 
modifiche'; 
$_MODULE['<{relatedfree}prestashop>tabs_7ac24d6ee168c8d39992c0c59171fd92'] = 
'Vuoi saperne di più opzioni di visualizzazione?'; 
$_MODULE['<{relatedfree}prestashop>tabs_34749ebdcabd53ce9171aefc837f71ec'] = 
'Vuoi visualizzare i prodotti in qualsiasi ordine?'; 
$_MODULE['<{relatedfree}prestashop>tabs_339517f38f0df46f9e4283b34a65d412'] = 
'Vuoi selezionare i prodotti specifici da visualizzare?'; 
$_MODULE['<{relatedfree}prestashop>tabs_12bf350cb48f3fa45af36abb5860b37d'] = 
'Si desidera aggiungere altri prodotti simili sotto forma di 
segnalibri?'; 
$_MODULE['<{relatedfree}prestashop>tabs_fe6c1af2438c25b00cbb6400da54f6a1'] = 
'Vuoi creare un numero qualsiasi di blocchi / segnalibri?'; 
$_MODULE['<{relatedfree}prestashop>tabs_824c644d076c03565a2a5aabdc0957bc'] = 
'Volete la soluzione migliore per la creazione \"simile\" prodotto?'; 
$_MODULE['<{relatedfree}prestashop>tabs_0ba4439ee9a46d9d9f14c60f88f45f87'] = 
'Controllare'; 
$_MODULE['<{relatedfree}prestashop>tabs_22884db148f0ffb0d830ba431102b0b5'] = 
'Modu&#322;o'; 
$_MODULE['<{relatedfree}prestashop>tabs_846b75ee07b94396c75ec27d5b58fd9e'] = 
'Elenco di prodotti simili'; 
$_MODULE['<{relatedfree}prestashop>tabs_f9edc7482d3eff492319e6c033e9cf55'] = 
'ID categoria'; 
$_MODULE['<{relatedfree}prestashop>tabs_7415647ac5fbdc4f5946d36d7a81cca4'] = 
'dove trovare ID categoria?'; 
$_MODULE['<{relatedfree}prestashop>tabs_990fc90e39367377c314f1d61522ae61'] = 
'Numero di prodotti'; 
$_MODULE['<{relatedfree}prestashop>tabs_9ea67be453eaccf020697b4654fc021a'] = 
'Salva modifiche'; 
$_MODULE['<{relatedfree}prestashop>products16_38070661d5ad384d9c7d21895dc4e784'] = 'Prodotti 
correlati'; 
$_MODULE['<{relatedfree}prestashop>products16_1a8c0228da8fb16885881e6c97b96f08'] = 'Nessun 
prodotto';