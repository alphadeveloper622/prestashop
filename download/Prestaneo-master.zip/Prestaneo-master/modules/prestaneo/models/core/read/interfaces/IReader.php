<?php

/**
 * Interface IReader
 */
interface IReader
{
    public function getData();
}