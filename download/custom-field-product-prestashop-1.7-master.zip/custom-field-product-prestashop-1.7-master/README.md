Add custom field to prestashop product.
